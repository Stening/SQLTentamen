﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TentaForm : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        using (SqlConnection conn = new SqlConnection("Data Source=CHIVAS2;Initial Catalog=MovieRenting;Integrated Security=True;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
        {
            conn.Open();

            using (SqlCommand test = conn.CreateCommand())
            {
                //SqlCommand test = new SqlCommand("CreateOrder", conn);
                test.CommandType = System.Data.CommandType.StoredProcedure;
                test.CommandText = "1ViewReturnListByDate";
                test.Parameters.AddWithValue("@date", TextBox1.Text);
                test.ExecuteNonQuery();
            }
        }
    }
}